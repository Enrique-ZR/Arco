La diferencia entre mí máquina y la de Devcloud es:
 - Mi procesador es un Intel(R) Core(TM) i7-8750H, mientras que el de la máquina de Devcloud es Intel Xeon Processor
- Mi procesador tiene 12 Cores mientras que el de Devcloud tiene 10
- Mi procesador tiene 2 hilos por núcleo mientras que el de intel tiene 1
- La capacidad en las caches L1 es igual 32K mientras que en la L2 mi máquina tiene 256k mientas que la de Devcloud tiene 4096K. Lo extraño es que no me aparece ninguna cache L3 en la máquina de Devcloud, mientras que la mía tiene una capacidad de 9216K
- Puedo sacar la conclusión que al no haber una Cache L3, si no una cache L2 con mucha capacidad en Devcloud los programas van más rapido porque están más cerca de la L1. Puedo sacar esta conclusión ya que nos han enseñado en clase que la distancia al transportar información es muy importante para mantener velocidades altas, cuanto más cerca estén los componentes más altas son las velocidades y por eso hemos dicho que la L2 como está más cerca de la L1 transporta la información más rápido y se ejecuta antes los programas.
