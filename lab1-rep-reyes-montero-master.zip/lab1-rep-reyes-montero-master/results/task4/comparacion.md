Podemos denotar las siguientes diferencias al haber hecho el analisis en mi propia maquina y el servidor de devcloud
 - El tiempo ha disminuido 2 segundos en la maquina de Devcloud respecto a mi maquina. Esto, a mi entender, se debe al hardware de la misma, al tener un hardware superior el tiempo para hacer el analisis disminuye
 - Debido a un problema con el advisor nos da el error
 advisor: Error: Insufficient memory
 Por tanto la memoria no la hemos podido medir con precision la parte de memoria. Se ha intentando con el qsub para no cargar demasiado pero aun asi sigue dando el mismo problema.
