Hemos realizado los siguientes comandos para hacer el analisis en devcloud

1. Conexión con el servidor devcloud
```
ssh devcloud
```
2. Copia de los archivos locales al servidor de devcloud con ```scp```

3. Analisis con advisor en devcloud
```
/glob/development-tools/versions/oneapi/2023.2.0.1/oneapi/advisor/2023.2.0/bin64/advisor -collect survey -project-dir /home/u204088/resultados --app-working-dir=/home/u204088 -- /home/u204088/task1.txt   | qsub  
/glob/development-tools/versions/oneapi/2023.2.0.1/oneapi/advisor/2023.2.0/bin64/advisor -collect tripcounts -flop -project-dir /home/u204088/resultados --app-working-dir=/home/u204088 -- /home/u204088/task1.txt | qsub
```
4. Hacemos el snapshot 
```
advisor --snapshot --no-pack –project-dir=./resultados.advixeproj
```
5. Copiamos la carpeta de resultados a nuestro repositorio local con 
```
scp -r devcloud:/home/u204088/resultados /home/enrique
```

