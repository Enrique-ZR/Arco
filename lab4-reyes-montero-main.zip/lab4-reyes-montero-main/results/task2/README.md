# Tarea 2: Análisis de Threading
## Preguntas

* Procede a realizar el análisis de threading hasta el análisis **Suitability**

* Antes de comenzar a interpretar los resultados es importante saber la información representada. Ve a la pestaña Suitability Report y responde a las siguientes preguntas:
    * ¿Qué representa el gráfico Scalability of Maximum Site Gain? ¿Para que sirven las opciones Avg. Number of Iterations y Avg. Iteration Duration?
      - **Scalability of Maximum Site Gain**: Este gráfico resume el rendimiento de cada uno de los Sites que se indiquen en el código. El número de procesadores de la simulación aparece en el 
          eje X y la ganancia de rendimiento prevista, se muestra en el eje Y. Mostrando cual es el valor de la ganancia en velocidad para un número concreto de CPUs simuladas.
      - **Avg. Number of Iterations**: Esta opción se encuentra dentro del área de **Loop Iterations (Tasks) Modeling** que sirve para observar como cambia el rendimiento previsto para el
        Site seleccionado al variar el número de iteraciones. Se muestra el valor del número medio de iteraciones, y se muestran distintos valores para aumentarlo un número de veces (5, 25, 125)
        o disminuirlo (0.2, 0.04, 0.008). Al clicar en el botón **Apply** se pueden observar las distintas estimaciones de rendimiento previstas para las distintas combinaciones de valores 
        seleccionados.
      - **Avg. Iteration Duration**: Esta opción se encuentra como la anterior dentro del área **Loop Iterations (Tasks) Modeling**. En este caso, esta opción sirve para variar la duración 
        media de la iteración en una cantidad mayor o menor de veces el valor de tiempo de la iteración media, valor que se nos muestra justo debajo de la opción. Como en la opción anterior,
        se puede aumentar o disminuir proporcionalemte un número de veces prefijadas y después pulsar el botón **Apply** para observar los resultados.
         
    * Explica que significa cada campo de las columnas **Impact to Program Gain**, **Combined Site Metrics, All Instances** y **Site Instance Metrics, Parallel Time**
      - **Impact to Program Gain**: Indica cual es el impacto, o cuánto contribuye ese site en concreto, a la ganancia o aceleración de velocidad del programa para todos los sitios.
      - **Combined Site Metrics, All Instances**: Se divide en 3 columnas y muestra una combinación de métricas de ejecución serie y paralela:
      	- **Total Serial Time**: Indica cual es el tiempo de ejecución serie del site, sin aplicar paralelismo.
        - **Total Parallel Time**: Indica cual es el tiempo de ejecución si aplicamos técnicas de programación paralela en el programa en ese site.
        - **Site Gain**: Indica la ganancia o aceleración esperada al paralelizar esa parte del código con respecto a la versión serie. El valor de este campo, es el resultado
          de la división de _Total Serie Time entre Total Parallel Time_.
      - **Site Instance Metrics, Parallel Time**: Este campo muestra también el tiempo de ejecución paralela del site seleccionado.

* Analiza la escalabilidad de la ganancia por cada Site que has declarado:
    * En primer lugar configura el reporte acorde a tu sistema y al modelo de paralelización con hilos que vayas a utilizar.
    * Realiza un snapshot y guárdalo con el nombre task2 en la carpeta [task2](/results/task2)
* Indica para cada uno de los sites definidos, a partir de qué número de CPUs la ganancia deja de mejorar o incluso empeora, y justifica la razón por la cual ocurre.
    - **Bucle 1**: El Site Gain aumenta hasta que el CPU Count llega a 8.
    - **Bucle 2**: El Site Gain aumenta hasta que el CPU Count llega a 8.
    - **Bucle 3**: El bucle 3 desde el momento que se le asignan 2 CPU empieza a empeorar ya que al igual que el bucle 4 y 5 no se puede paralelizar debido a que tiene que llegar en un orden específico y no se puede dividir la tarea en hilos.
    
*SI fijamos el Site Gain va aumentando en gran medida hasta que llega a cierto número de CPUs, esto lo podemos considerar el umbral en el cual si aumentamos el número de CPUs la ganancia disminuye, esto está relacionado con la Ley de Amdhal y el false sharing cache que se trata de un patrón de uso que podría impactar negativamente en el rendimiento de las cachés distribuidas con coherencia, especialmente en los bloques de recursos de menor tamaño administrados por el mecanismo de caché.*




* ¿Cuál de los bucles definidos en el código supone un mayor tiempo de ejecución del programa? ¿Cómo afectaría a la ganancia de este Site si, usando el máximo número de CPUs de la simulación (64), en vez de usar bloques de tamaño de 1024 se reduce a 256? Indica cómo has obtenido este nueva ganancia.
	- Partimos de que nos centramos en el total time, el bucle que mas tiempo consume es el subtractingInfo, si la función que opera sobre estos bloques se ejecuta en paralelo y se distribuye en múltiples CPUs, la reducción del tamaño del  bloque puede implicar una menor cantidad de trabajo distribuido a las CPUs, lo que podría disminuir la eficiencia del paralelismo. Es decir, que si antes se dividía el trabajo en bloques de 1024 y ahora en bloques de 256, habrá menos trabajo para distribuir entre las CPUs, lo que puede resultar en una menor ganancia al usar las 64 CPUs.
	
----


# Task 2: Threading Analysis
## Questions

* Proceed with the threading analysis up to the **Suitability** analysis.

* Before interpreting the results, it is important to understand the represented information. Go to the Suitability Report tab and answer the following questions:
    * What does the Scalability of Maximum Site Gain graph represent? What are the purposes of the Avg. Number of Iterations and Avg. Iteration Duration options?
    * Explain the meaning of each field in the columns **Impact to Program Gain**, **Combined Site Metrics, All Instances** y **Site Instance Metrics, Parallel Time**

* Analyze the scalability of gain for each of the Sites you've defined:
    * First, configure the report according to your system and the threading model you plan to use.
    * Take a snapshot and save it with the name task2 in the [task2](/results/task2) folder.
    * For each of the defined Sites, specify from how many CPUs the gain ceases to improve or even worsens, and justify why this occurs.
    * Which of the loops defined in the code consumes the most execution time in the program? How would reducing the block size from 1024 to 256, using the maximum number of CPUs in the simulation (64), affect the gain of this Site? Explain how you obtained this new gain.
