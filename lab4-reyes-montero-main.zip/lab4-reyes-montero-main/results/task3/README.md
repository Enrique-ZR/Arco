# Tarea 3: Paralelización con OpenMP

## Preguntas
* Una vez realizados los análisis correspondientes paraleliza el programa todo lo que puedas, incluso puedes modificar parte del código original facilitado para esta práctica. Ten en cuenta que es posible que requiera usar modificadores de memoria o mecanismos de sincronización.

* ¿Cuántos hilos hay disponibles? ¿A qué crees que se debe este resultado?

* Comprueba que la ejecucion paralela y secuencial es la misma. ¿Cómo lo has comprobado?
  - Comprobando visualmente que la salida es la misma. Produce la misma numeración y en el mismo orden que la ejecución serie.

* Realiza mediciones de tiempo para 2, 4, 8, 16, 32 y 64 hilos y añade los resultados de tiempo en una tabla junto a los resultados secuenciales. Además añade la ganancia obtenida por cada ejecución en comparación con la secuencial ¿Estos resultados se corresponden o se parecen a los estimados por Intel Advisor? Justifica tu respuesta.
  - El tiempo de ejecución serie ha sido **0m5,569s** obtenido con el comando time.

| Nº hilos  |     2     |    4      |     8     |     16    |      32   |    64     |
|:---------:|:---------:|:---------:|:---------:|:---------:|:---------:|:---------:|
| Tiempo(s) | 0m4,297s  |0m3,685s   | 0m3,617s  | 0m3,650s  |0m4,034s   | 0m4,232s  |
|  Ganancia  | 1,296    | 1,511     |  1,539    |  1,525    |  1,380    |  1,31     |  

La ganancia se ha obtenido como el tiempo original serie **(0m5,569s)** dividido entre cada uno de los tiempos obtenidos de ejecución para cada número distinto de hilos (tiempo mejorado)

Los resultados son coincidentes con los suministrado en Intel Advisor, observando que el punto dulce de máxima ganancia se obtiene con 8 hilos, viendo que el rendimiento comienza a degradarse
ligeramente a partir de 16 hilos y de manera algo más acusada con 32 y 64 hilos de ejecución.



# Task 3: Parallelization with OpenMP

## Questions
* After performing the relevant analyses, parallelize the program to the greatest extent possible, and you can even modify parts of the original code provided for this practice. Keep in mind that you may need to use memory modifiers or synchronization mechanisms.

* How many threads are available, and what do you think is the reason for this result?

* Ensure that both parallel and sequential execution produce the same results. How did you verify this?

* Perform time measurements for 2, 4, 8, 16, 32, and 64 threads and add the time results to a table alongside the sequential results. Additionally, include the gain achieved for each execution compared to the sequential one. Do these results correspond to or resemble those estimated by Intel Advisor? Justify your answer.
